#/bin/bash
git pull
git add .
git commit -m "stuff" 
git push origin master

