# ssiweb
projet sur la sécurité des systèmes d'information WEB basé sur DVWA 

Distribution trouée Damn Vulnerable Web Application 

http://www.dvwa.co.uk/

"Damn Vulnerable Web App (DVWA) is a PHP/MySQL web application that is damn vulnerable. Its main goals are to be an aid for security professionals to test their skills and tools in a legal environment, help web developers better understand the processes of securing web applications and aid teachers/students to teach/learn web application security in a class room environment."
